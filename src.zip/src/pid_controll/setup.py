from setuptools import setup, find_packages
from glob import glob
import os

package_name = 'pid_controll'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Mugis',
    maintainer_email='Mugis@todo.todo',
    description='PID controller package',
    license='TODO',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'controller = pid_controll.controller:main',
        ],
    },
)